1) Please unzip the current_posts in the folder [your drive]:\sites\[yoursite]\sites\all\modules
2) While you have logged on into your site on drupal system, you could find the current_posts module being populated as you navigate to Home>>Administration>>Modules and scroll down to the Other category. Please check the box and enable the current_posts module.
3) Save the configuration
4) Please navigate to Home>>Administration>>Structure and scroll down to the disabled property list where you will find current_posts. And set its location to one of the page regions.
 

